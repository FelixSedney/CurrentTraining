﻿using MyCollectionLib;
using System;

namespace GenericsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            MyCollection<int> myCollection = new MyCollection<int>();
            myCollection.Add(12);
            myCollection.Add(23);
            myCollection.Add(34);

            //for (int i = 0; i < myCollection.Length; i++)
            //{
            //    Console.WriteLine(myCollection[i]);
            //}

            foreach (var item in myCollection)
            {
                Console.WriteLine(item);
            }
        }
    }
}

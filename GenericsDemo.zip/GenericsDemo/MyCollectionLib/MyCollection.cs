﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace MyCollectionLib
{

    //T is een type parameter
    public class MyCollection<T>:IEnumerable<T> where T:struct//type constraint
    { 
        //object[] zou het breder toepasbaar maken
        //het is dan niet meer type save
        //je krijgt evt (un)boxing
        private T[] _arr;
        //private int[] _arr;
        public int Size { get; private set; }
        public int Length { get; set; }


        public T this[int index]
        //public int this[int index]
        {
            get { return _arr[index]; }
            set { _arr[index] = value; }
        }


        public MyCollection(int size = 10)
        {
            Size = size;
            _arr = new T[Size];
            //_arr = new int[Size];
            Length = 0;
        }

        public void Add(T value)
        //public void Add(int value)
        {
            //checken of het wel kan
            _arr[Length++] = value;
        }

        public IEnumerator<T> GetEnumerator()
        {
            for (int i = 0; i < Length; i++)
            {
                yield return _arr[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }
}

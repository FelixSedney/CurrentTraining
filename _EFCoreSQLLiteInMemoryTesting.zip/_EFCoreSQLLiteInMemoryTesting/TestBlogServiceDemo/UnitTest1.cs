using DAL;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace TestBlogServiceDemo
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void GetAllBlogs_Returns_4()
        {
            using (var connection = new SqliteConnection("DataSource=:memory:"))
            {
                connection.Open();
                var options = new DbContextOptionsBuilder<BlogContext>()
                    .UseSqlite(connection)
                    .Options;
                using (BlogContext context = new BlogContext(options))
                {
                    Seed(context);
                    BlogService service = new DAL.BlogService(context);
                    var result = service.GetAllBlogs();
                    Assert.AreEqual(4, result.Count);
                }
            }
        }

        [TestMethod]
        public void GetFirstBlogs_Returns_BlogA()
        {
            using (var connection = new SqliteConnection("DataSource=:memory:"))
            {
                connection.Open();
                var options = new DbContextOptionsBuilder<BlogContext>()
                    .UseSqlite(connection)
                    .Options;
                using (BlogContext context = new BlogContext(options))
                {
                    Seed(context);
                    BlogService service = new DAL.BlogService(context);
                    var result=service.GetBlogByID(1);
                    Assert.AreEqual("BlogA", result.Title);
                    Assert.
                }
            }
        }

                    private void Seed(BlogContext context)
        {
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();
            List<Blog> blogs = new List<Blog>()
            {
                new Blog(){ Title="BlogA"},
                new Blog(){ Title="BlogB"},
              new Blog(){ Title="BlogC"},
                new Blog(){ Title="BlogD"}

            };
            context.Blogs.AddRange(blogs);
            context.SaveChanges();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DAL
{
    public class Blog
    {
        public string Title { get; set; }
        public int BlogID { get; set; }
        public ICollection<Post> Posts { get; set; }

    }
}

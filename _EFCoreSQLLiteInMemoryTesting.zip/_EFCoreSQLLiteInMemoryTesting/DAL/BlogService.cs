﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
 public   class BlogService
    {
        private BlogContext _context;

        public BlogService(BlogContext context)
        {
            _context = context;
        }

        public List<Blog> GetAllBlogs()
        {
            return _context.Blogs.OrderBy(b => b.Title).ToList();
        }

        public List<Post> GetAllPosts()
        {
            return _context.Posts.OrderBy(p => p.Text).ToList();
        }

        public int AddBlog(Blog newBlog)
        {
            _context.Blogs.Add(newBlog);
            _context.SaveChanges();
            return newBlog.BlogID;
        }

        public Blog GetBlogByID(int id)
        {
            return _context.Blogs.Find(id);
        }

        public Blog GetBlogByIDEagerLoadPosts(int id)
        {
            var result = _context.Blogs.Where(b => b.BlogID == id)
                .Include(b => b.Posts)
                .SingleOrDefault();
            return result;


        }
    }
}

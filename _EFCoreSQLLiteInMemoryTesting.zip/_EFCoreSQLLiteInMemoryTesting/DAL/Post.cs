﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DAL
{
    public class Post
    {
        public int PostID { get; set; }
        public string Text { get; set; }
        public string Author { get; set; }
        public Blog Blog { get; set; }

    }
}

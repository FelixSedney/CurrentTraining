﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace BackGroundWorkerDemo
{
    public partial class Form1 : Form
    {
        string result=string.Empty;
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripProgressBar1.Increment(10);
            if (toolStripProgressBar1.Value == toolStripProgressBar1.Maximum)
            {
                toolStripProgressBar1.Value = 0;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            //GetFolders("c:\\inetpub");
            

            backgroundWorker1.DoWork += new DoWorkEventHandler(backgroundWorker1_DoWork);
            backgroundWorker1.RunWorkerCompleted += new RunWorkerCompletedEventHandler(backgroundWorker1_RunWorkerCompleted);
            backgroundWorker1.RunWorkerAsync();
           
        }

        void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            richTextBox1.Text = result;
            timer1.Enabled = false;
        }

        void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            GetFolders("c:\\inetpub");
        }

        private void GetFolders(string path)
        {
            string[] folders= Directory.GetDirectories(path);
            Thread.Sleep(100);
            if (folders.Length > 0)
            {
                foreach (var item in folders)
                {
                    GetFolders(item);
                    result = result + string.Format("{0}\n", item);
                }
            }
        }
    }
}

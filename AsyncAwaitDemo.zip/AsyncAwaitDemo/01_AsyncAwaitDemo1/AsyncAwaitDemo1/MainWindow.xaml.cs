﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace AsyncAwaitDemo1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        delegate long FacDelegate(object x);
     DispatcherTimer _timer;

        public MainWindow()
        {
            InitializeComponent();
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromMilliseconds( 1000);
            _timer.Tick += _timer_Tick;
        }

        void _timer_Tick(object sender, EventArgs e)
        {
            ProgressBar1.Value+=10;
        }

        

        //private void CalculateButton_Click_1(object sender, RoutedEventArgs e)
        //{
        //    _timer.Start();
        //    FacDelegate fd = new FacDelegate(Faculty);
        //    fd.BeginInvoke(ValueTextBox.Text, new AsyncCallback(FacultyCallback), fd);
        //}


        private async void CalculateButton_Click_1(object sender, RoutedEventArgs e)
        {
            _timer.Start();
            long result = await FactorialAsync(ValueTextBox.Text);
            ResultTextBlock.Text = result.ToString();
            _timer.Stop();
        }


        long Factorial(object o)
        {
            int x = int.Parse(o.ToString());
            Thread.Sleep(500);
            if (x == 0 || x == 1)
            {
                return 1;
            }
            else
            {
                return x * Factorial(x - 1);
            }
        }

        //void FacultyCallback(IAsyncResult iar)
        //{
        //    FacDelegate fd = iar.AsyncState as FacDelegate;
        //    long result = fd.EndInvoke(iar);
        //    //ResultTextBox.Text = result.ToString();
        //    ResultTextBlock.Dispatcher.Invoke(() => ResultTextBlock.Text = result.ToString());
        //    _timer.Stop();
        //    ProgressBar1.Dispatcher.Invoke(() => ProgressBar1.Value = 0);
        //}

         Task<long> FactorialAsync(object x)
        {
            Task<long> t = new Task<long>(Factorial, x);
            t.Start();
            return t;
        }
    }
}

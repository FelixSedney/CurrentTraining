﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using System.IO;
using System.Windows.Threading;
using System.Collections.ObjectModel;
using System.Threading.Tasks;

namespace M8_17_TPL
{

    delegate void GetResultDelegate(List<string> images);

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer timer;
        List<string> _imageCollection = new List<string>();


        public MainWindow()
        {
            InitializeComponent();
        }

        private async void GetImagesButton_Click(object sender, RoutedEventArgs e)
        {
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(500);
            timer.Tick += new EventHandler(timer_Tick);
            timer.Start();

            //Task t = new Task(()=>GetAllImages(@"c:\images"));
            //t.Start();
            ImageUtil imageUtil = new ImageUtil();
            _imageCollection = await imageUtil.GetAllImagesAsync(@"c:\images");
            //ImageListBox.Dispatcher.Invoke(new GetResultDelegate(GetResult), imageUtil.GetAllImages(@"c:\images"));
            ImageListBox.ItemsSource = _imageCollection;
            ImageListBox.SelectedIndex = 0;
            timer.Stop();
        }
        private void GetAllImages(object o)
        {
            ImageUtil imageUtil = new ImageUtil();
            ImageListBox.Dispatcher.Invoke(new GetResultDelegate(GetResult), imageUtil.GetAllImages(o.ToString()));
        }

        void timer_Tick(object sender, EventArgs e)
        {
            if (LoadProgress.Value == LoadProgress.Maximum)
            {
                LoadProgress.Value = 0;
            }
            LoadProgress.Value += 10;
        }

        private void GetResult(List<string> images)
        {
            ImageListBox.ItemsSource = images;
            ImageListBox.SelectedIndex = 0;
            timer.Stop();
        }
    }
}

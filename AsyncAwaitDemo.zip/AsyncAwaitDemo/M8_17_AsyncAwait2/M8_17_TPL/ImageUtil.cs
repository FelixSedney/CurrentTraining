﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace M8_17_TPL
{
    public class ImageUtil
    {
        public List<string> GetAllImages(object o)
        {

            List<string> _imageCollection = new List<string>();

            string path = o.ToString();
            string[] files = Directory.GetFiles(path, "*.jpg");

            foreach (var file in files)
            {
                 Thread.Sleep(100);
                _imageCollection.Add(file);
            }
            return _imageCollection;
        }


        public  Task<List<string>> GetAllImagesAsync(object o)
        {
            List<string> _imageCollection = new List<string>();
            string path = o.ToString();
            Task<List<string>> t = new Task<List<string>>(() =>
            {
                string[] files = Directory.GetFiles(path, "*.jpg");
                foreach (var file in files)
                {
                    Thread.Sleep(100);
                    _imageCollection.Add(file);
                }
                return _imageCollection;
            });
            t.Start();
            return t;
        }
    }
}

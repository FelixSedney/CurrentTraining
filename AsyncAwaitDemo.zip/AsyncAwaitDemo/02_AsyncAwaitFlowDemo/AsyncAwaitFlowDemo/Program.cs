﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AsyncAwaitFlowDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //The behavior in a console application differs from the behavior in windows/WPF applications
            Task t = MethodA();
            t.ContinueWith(new Action<Task>((ct) => Console.WriteLine("done")));//this Action is run  asynchronous when t has completed.

            Console.WriteLine("Waiting in Main method ThreadID: {0}",Thread.CurrentThread.ManagedThreadId);
            Console.ReadKey();

        }

        static async Task MethodA()
        {
            Console.WriteLine("Start MethodA ThreadID: {0}",Thread.CurrentThread.ManagedThreadId);
            await MethodB();
            Console.WriteLine("End MethodA ThreadID:  {0}", Thread.CurrentThread.ManagedThreadId);//the compiler turns this line into a callback 
        }

        private static async Task MethodB()
        {
            Console.WriteLine("\tStart MethodB  ThreadID: {0}",Thread.CurrentThread.ManagedThreadId);
            await Task.Delay(1000);
            await MethodC();
            Console.WriteLine("\tEnd MethodB ThreadID: {0}", Thread.CurrentThread.ManagedThreadId); 
        }

        private static async Task MethodC()
        {
            Console.WriteLine("\t\tStart MethodC ThreadID: {0}", Thread.CurrentThread.ManagedThreadId);
            await Task.Delay(1000);
            Console.WriteLine("\t\tEnd MethodC  ThreadID: {0}", Thread.CurrentThread.ManagedThreadId);
        }
    }
}

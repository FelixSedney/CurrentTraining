﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication8
{
    class Program
    {
        static void Main(string[] args)
        {
            Whatever();

            Console.WriteLine("done");
            Console.ReadKey();
        }

        static private async void Whatever()
        {
            int result = await Process.Start("notepad.exe");
            Console.WriteLine("Process ended with code {0}", result);
        }
    }

    static class ProcessExtension
    {
        public static TaskAwaiter<int> GetAwaiter(this Process process)
        {
            TaskCompletionSource<int> tcs = new TaskCompletionSource<int>();
            process.EnableRaisingEvents = true;
            process.Exited += (o, e) => tcs.TrySetResult(process.ExitCode);
            return tcs.Task.GetAwaiter();
        }
    }
}

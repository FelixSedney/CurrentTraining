﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        delegate long Mathdelegate(int x);

        public MainWindow()
        {
            InitializeComponent();
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            long result = await FacultyAsync(int.Parse(ValueTextBox.Text));
            ResultTextBlock.Text = result.ToString();

           
        }

          private static   Task<long> FacultyAsync(int x)
        {
            Mathdelegate md = new Mathdelegate(Faculty);
            return Task<long>.Factory.FromAsync(md.BeginInvoke(x,null,null), md.EndInvoke, TaskCreationOptions.None);
        }

        private static long Faculty(int x)
        {
            Thread.Sleep(200);
            if(x==0)
            {
                return 1;
            }
            else
            {
                return x * Faculty(x - 1);
            }
        }
    
    }
}

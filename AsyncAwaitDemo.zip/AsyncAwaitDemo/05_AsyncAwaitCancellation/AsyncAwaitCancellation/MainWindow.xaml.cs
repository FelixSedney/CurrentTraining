﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AsyncAwaitCancellation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        CancellationTokenSource _cts;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void CancelButton_Click_1(object sender, RoutedEventArgs e)
        {
            if (_cts != null)
            {
                _cts.Cancel();
            }
        }

        private async void DownLoadButton_Click_1(object sender, RoutedEventArgs e)
        {
            _cts = new CancellationTokenSource();
            //_cts.CancelAfter(2000);bij 1500 wordt de download gecancelled. Cancel button dan niet gebruiken
            ResultTextBlock.Text = "";
            try
            {
                int contentLength = await ProcessURLAsync("http://msdn.microsoft.com/library/windows/apps/br211380.aspx", _cts.Token);
                ResultTextBlock.Text += string.Format("\nDownloaded string has length {0}", contentLength);
            }
            catch (OperationCanceledException ex)
            {
                ResultTextBlock.Text += string.Format("\nDownload cancelled.");

            }
            finally
            {
                _cts = null;
            }
        }

        async Task<int> ProcessURLAsync(string url, CancellationToken cancellationToken )
        {
            HttpClient client = new HttpClient();
            // Task.Delay(1000);
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            HttpResponseMessage result = await client.GetAsync(url, cancellationToken);
            byte[] resultArray = await result.Content.ReadAsByteArrayAsync();
            return resultArray.Length;
        }
    }
}

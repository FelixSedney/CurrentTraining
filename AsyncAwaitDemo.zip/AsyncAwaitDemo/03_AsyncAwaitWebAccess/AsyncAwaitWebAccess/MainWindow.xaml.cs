﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AsyncAwaitWebAccess
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<string> _urlList;

        public MainWindow()
        {
            InitializeComponent();
        }

        private async  void DownLoadButton_Click_1(object sender, RoutedEventArgs e)
        {
            ResultTextBlock.Text = "";
            await SumPageSizesAsync();
             //SumPageSizes();
            ResultTextBlock.Text += "\ndone";
        }

        //private void SumPageSizes()
        private async  Task SumPageSizesAsync()
        {
            int total = 0;
            foreach (var url in _urlList)
            {
                ResultTextBlock.Text += "\nnext iteration";
                byte[] urlContents =  await GetUrlContentsAsync(url);
                var bytes = urlContents.Length;
                ResultTextBlock.Text += string.Format("\n{0}\t{1}",url.Substring(7), bytes);
                total += bytes;

            }
            ResultTextBlock.Text += string.Format("\n{0}", total);
        }

        

        private async Task<byte[]> GetUrlContentsAsync(string url)
        {
            // using System.Net;
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            // Use SecurityProtocolType.Ssl3 if needed for compatibility reasons
            MemoryStream memoryStream = new MemoryStream();
            HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
            using (WebResponse response = await httpWebRequest.GetResponseAsync())
            {
                using (Stream stream = response.GetResponseStream())
                {
                    await stream.CopyToAsync(memoryStream);
                }
            }
            return memoryStream.ToArray();
        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {
           _urlList = new List<string>(){
                "http://msdn.microsoft.com/library/windows/apps/br211380.aspx",
        "http://msdn.microsoft.com/en-us/library/hh290136.aspx",
        "http://msdn.microsoft.com/en-us/library/ee256749.aspx",
        "http://msdn.microsoft.com/en-us/library/hh290138.aspx",
        "http://msdn.microsoft.com/en-us/library/hh290140.aspx",
        "http://msdn.microsoft.com/en-us/library/dd470362.aspx",
        "http://msdn.microsoft.com/en-us/library/aa578028.aspx",
        "http://msdn.microsoft.com/en-us/library/ms404677.aspx",
        "http://msdn.microsoft.com/en-us/library/ff730837.aspx"

            };
        }
    }
}

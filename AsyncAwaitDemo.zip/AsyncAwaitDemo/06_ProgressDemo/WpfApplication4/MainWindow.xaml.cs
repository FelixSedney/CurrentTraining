﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {


        public MainWindow()
        {
            InitializeComponent();
        }

        private async void bt1_Click(object sender, RoutedEventArgs e)
        {
            Progress<int> progress = new Progress<int>((x) =>
            {
                tb1.Text += x; tb1.Text += "\n";
                pb1.Value = x;
            });
            await ReadFileAsync(progress);
            tb1.Text += "done\n";
        }

        private async Task ReadFileAsync(IProgress<int> progress)
        {
            Stream stream = File.OpenRead(@"c:\temp\instpubs.sql");
            pb1.Maximum = stream.Length;

            byte[] buffer = new byte[200];

            int total = 0;
            int bytesRead;
            do
            {
                bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                total += bytesRead;
                progress.Report(total);
                await Task.Delay(500);//
            }
            while (bytesRead >= buffer.Length);
        }
    }

}


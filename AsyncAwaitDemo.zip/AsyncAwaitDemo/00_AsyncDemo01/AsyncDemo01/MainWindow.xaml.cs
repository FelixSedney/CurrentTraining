﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AsyncDemo01
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        List<string> _folders = new List<string>();
        List<string> _logFiles = new List<string>();
        System.Timers.Timer _timer;


        private async void ShowButton_Click(object sender, RoutedEventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            _timer.Start();
            ProjectsListBox.ItemsSource = _folders;
            StatusTextBlock.Text = "Searching";
            // GetFolders(@"c:\Scripts");
            await GetFoldersAsync(@"c:\Scripts");
            //GetFolders(@"c:\inetpub");
            ProjectsListBox.ItemsSource = _folders;
            StatusTextBlock.Text = "Ready";
            _timer.Stop();
            Pb1.Value = 0;
            TimeTextBlock.Text = stopwatch.ElapsedTicks.ToString();
        }



        private Task GetFoldersAsync(string path)
        {
            Task t = Task.Factory.StartNew(() => GetFolders(path));
            return t;
        }

        private void GetFolders(string path)
        {
            Thread.Sleep(20);
            foreach (var item in Directory.GetDirectories(path))
            {
                _folders.Add(item);
                foreach (var file in Directory.GetFiles(item))
                {
                    _folders.Add("  " + file);
                }
                foreach (var subFolder in Directory.GetDirectories(item))
                {
                    GetFolders(subFolder);
                }
            }
        }


        private async void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            _timer.Start();
            SearchListBox.ItemsSource = _logFiles;
            StatusTextBlock.Text = "Searching";
            //SearchFolders(@"c:\windows");
            await SearchFoldersAsync(@"c:\windows");
            StatusTextBlock.Text = "Ready";
            _timer.Stop();
            Pb1.Value = 0;
            TimeTextBlock.Text = stopwatch.ElapsedTicks.ToString();
        }

        private Task SearchFoldersAsync(string path)
        {
            Task t = Task.Factory.StartNew(() => SearchFolders(path));
            return t;
        }
     

        private void SearchFolders(string path)
        {
            DirectoryInfo di = new DirectoryInfo(path);
            foreach (var folder in di.GetDirectories())
            {
                try
                {
                    foreach (var file in folder.GetFiles())
                    {
                        if (file.Extension == ".log")
                        {
                            _logFiles.Add(file.Name);
                        }
                    }
                    foreach (var subFolder in folder.GetDirectories())
                    {
                        SearchFolders(subFolder.FullName);
                    }
                }
                catch (UnauthorizedAccessException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        private async void BothButton_Click(object sender, RoutedEventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            _timer.Start();
            StatusTextBlock.Text = "Search/Show";
           List<Task> tasks = new List<Task>()
            {
                 Task.Run(() => GetFolders(@"c:\scripts")),
                 Task.Run(() => SearchFolders(@"c:\windows"))
            };
            await Task.WhenAll(tasks);
              ProjectsListBox.ItemsSource = _folders;
            SearchListBox.ItemsSource = _logFiles;
            StatusTextBlock.Text = "Ready";
            _timer.Stop();
            Pb1.Value = 0;
            TimeTextBlock.Text = stopwatch.ElapsedTicks.ToString();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            _timer = new System.Timers.Timer(500);
            _timer.Elapsed += Timer_Elapsed;
        }


        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            Pb1.Dispatcher.Invoke(() => Pb1.Value = Pb1.Value % Pb1.Maximum + 10);
        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EF_Demo
{
public    class Person
    {
        //[Key]
        //public int whatever { get; set; }
        public int PersonId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public int Age { get; set; }

        public Person()
        {
        }

        public Person(string firstName,string lastName,string address,int age)
        {
            FirstName = firstName;
            LastName = lastName;
            Address = address;
            Age = age;

        }

        public override string ToString()
        {
            return $"{FirstName}\t{LastName}\t{Address}\t{Age}";
        }
    }
}

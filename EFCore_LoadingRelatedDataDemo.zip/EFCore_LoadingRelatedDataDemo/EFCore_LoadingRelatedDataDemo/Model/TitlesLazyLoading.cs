﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EFCore_LoadingRelatedDataDemo.Model
{
    partial class Titles
    {

    }
}

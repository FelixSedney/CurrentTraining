﻿using System;
using System.Collections.Generic;

namespace EFCore_LoadingRelatedDataDemo.Model
{
    public partial class Publishers
    {
        public Publishers()
        {
            Titles = new HashSet<Titles>();
        }

        public string PubId { get; set; }
        public string PubName { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }

        public virtual PubInfo PubInfo { get; set; }
        public virtual ICollection<Titles> Titles { get; set; }
    }
}

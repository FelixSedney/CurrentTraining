﻿using EFCore_LoadingRelatedDataDemo.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace EFCore_LoadingRelatedDataDemo
{
    class Program
    {
        static void Main(string[] args)
        {
       
            using (PubsContext context = new PubsContext())
            {

                var result = context.Titles.Where(t => t.Type == "business");

                foreach (var item in result)
                {
                    Console.WriteLine($"{item.Title}\t{item.Pub.PubName}\t{item.Pub.PubInfo}");
                }

                //var result = context.Titles.Include(t=>t.Pub).ThenInclude(t=>t.PubInfo).Where(t => t.Type == "business");

                //foreach (var item in result)
                //{
                //    Console.WriteLine($"{item.Title}\t{item.Pub.PubName}\t{item.Pub.PubInfo}");
                //}

                // var result = context.Titles.Where(t => t.Type == "business");
                //foreach (var item in result)
                //{
                //    context.Entry(item).Reference(t => t.Pub).Load();
                //    Console.WriteLine($"{item.Title}\t{item.Pub.PubName}");
                //}

                //var result = context.Publishers.Where(p => p.State == "CA");
                //foreach (var item in result)
                //{
                //    context.Entry(item).Collection(p => p.Titles).Load();
                //    Console.WriteLine(item.PubName);
                //    foreach (var title in item.Titles)
                //    {
                //        Console.WriteLine($"\t{title.Title}");

                //    }
                //}

            }

        }
    }
}

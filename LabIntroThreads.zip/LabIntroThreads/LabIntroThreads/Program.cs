﻿using System;

namespace LabIntroThreads
{
    class Program
    {
        static void Main(string[] args)
        {
            //Given a synchronous version of a program that prints a character in a certain color.
            //1 Run the program and observe the results.
            //2 Create an asynchronous version of this program, using threads. Observe the results.
            //3 Use several synchronisation objects, to avoid wrong results.

            WriteX("*", ConsoleColor.Cyan);
            WriteX("_", ConsoleColor.Yellow);
            Console.WriteLine("READY");
            Console.ReadKey();
        }

        static void WriteX(string s, ConsoleColor cc)
        {
            for (int i = 0; i < 1000; i++)
            {
                Console.ForegroundColor = cc;
                Console.Write(s);
            }
        }
    }
}

﻿using QueryingAnEntityDataModel.Model;
using System.Linq;
using System;

namespace QueryingAnEntityDataModel
{
    class Program
    {
        static void Main(string[] args)
        {
            using (PubsContext context = new PubsContext())
            {
                var result = context.Authors
                    .Where(au => au.State == "CA")
                    .Select(au => new { au.AuFname, au.AuLname });
                foreach (var item in result)
                {
                    Console.WriteLine($"{item.AuFname}\t{item.AuLname}");
                }
            }
        }
    }
}

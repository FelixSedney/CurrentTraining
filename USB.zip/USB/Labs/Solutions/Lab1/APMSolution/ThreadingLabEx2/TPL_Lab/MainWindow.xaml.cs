﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace TPL_Lab
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        int res = 0;
        object syncroot = new object();
        TextBox[] source;
        int numResults = 0;
        //TextBoxes are named TextBox1, TextBox2, TextBox3 and ResultTextBox
        private void CalculateButton_Click(object sender, RoutedEventArgs e)
        {
            source = new TextBox[] { TextBox1, TextBox2, TextBox3 };
            for (int i = 0; i < 3; i++)
            {
                int input = int.Parse(source[i].Text);
                Threading.SlowMath sm = new Threading.SlowMath();
                sm.BeginSquare(input, CalculateSlowCallback, sm);
            }


        }


        private void CalculateSlowCallback(IAsyncResult ia)
        {
            Threading.SlowMath sm = (Threading.SlowMath)ia.AsyncState;
            lock (syncroot)
            {
                res += sm.EndSquare(ia);
                if (++numResults == 3)
                {
                    this.ResultTextBox.Dispatcher.Invoke((Action<string>)(s => this.ResultTextBox.Text = s), res.ToString());
                }
            }
        }
    }
}

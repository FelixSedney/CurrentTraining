﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Threading
{
	class SlowMath
	{
		private Converter<int, int> _int2intDelegate;

		public SlowMath()
		{
			_int2intDelegate = Square;
		}


		public int Square(int n)
		{
			Thread.Sleep(3000);
			return n * n;
		}

		public IAsyncResult BeginSquare(int n, AsyncCallback callback, object state)
		{

			return _int2intDelegate.BeginInvoke(n, callback, state);
		}

		public int EndSquare(IAsyncResult ar)
		{
			return _int2intDelegate.EndInvoke(ar);
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Threading
{
	class ThreadStateContext
	{
		/// <summary>
		/// De synchronizatiecontext om berichten uit te wisselen met de UI thread.
		/// </summary>
		public SynchronizationContext SynchronizationContext { get; set; }

		/// <summary>
		/// Het getal om te kwadrateren.
		/// </summary>
		public int Getal { get; set; }
	}
}

﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using Threading;

namespace ThreadingLab {
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    { 

        public MainWindow()
        {
            InitializeComponent();
        }

        //TextBoxes are named TextBox1, TextBox2, TextBox3 and ResultTextBox



        /// <summary>
        /// Berekent het totaal van de vermenigvuldigde waarden.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void CalculateButton_Click(object sender, RoutedEventArgs e)
        {
            // Verwerk ingevoerd getal
            int geparsed;
            if (int.TryParse(TextBox1.Text, out geparsed) == false)
            {
                 MessageBox.Show("Vul aub hele getallen in");
                 return;
            }

            
            StatusLabel.Content = "Bezig met laden...";

            // Creëer een state om mee kan geven bij het starten van de thread
            var context = new ThreadStateContext()
            {
                 Getal = geparsed,
                 SynchronizationContext = SynchronizationContext.Current
            };

            // De thread starten
            var ts = new ParameterizedThreadStart(BerekenKwadraat);
            var t = new Thread(ts);
            StatusLabel.Content = "Berekenen...";

            t.Start(context);
            
        }


		/// <summary>
		/// Berekent het kwadraat van een getal, op een erg trage manier.
		/// 
		/// Deze functie wordt aangeroepen door de thread die wordt opgestart.
		/// </summary>
		private void BerekenKwadraat(object state)
		{
			// State is onze ThreadStateContext. Even casten om hem toegankelijk te maken
			var context = state as ThreadStateContext;

			// Het kwadraat kan nu berekend worden
			var slowMath = new SlowMath();
			var kwadraat = slowMath.Square(context.Getal);

			// Aan de hand van de synchronizationcontext kunnen we het resultaat van de berekening nu terugsturen
			context.SynchronizationContext.Post(new SendOrPostCallback(VerwerkResultaat), kwadraat);
		}

		/// <summary>
		/// Deze methode wordt aangeroepen door de SynchronizationContext wanneer de wiskundige berekening klaar is.
		/// </summary>
		private void VerwerkResultaat(object state)
		{
			// State is het berekende kwadraat
			var kwadraat = (int)state;

			ResultTextBox.Text = kwadraat.ToString();
            StatusLabel.Content = "gereed...";
		}
    }
}

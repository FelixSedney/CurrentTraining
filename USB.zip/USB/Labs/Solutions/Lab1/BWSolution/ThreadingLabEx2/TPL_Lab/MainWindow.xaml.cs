﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using System.ComponentModel;

namespace TPL_Lab
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        int res = 0;
        object syncroot = new object();
        TextBox[] source;

        BackgroundWorker[] bw = new BackgroundWorker[3];

        int numResults = 0;
        //TextBoxes are named TextBox1, TextBox2, TextBox3 and ResultTextBox
        private void CalculateButton_Click(object sender, RoutedEventArgs e)
        {
            source = new TextBox[] { TextBox1, TextBox2, TextBox3 };
            for (int i = 0; i < 3; i++)
            {
                int input = int.Parse(source[i].Text);
                bw[i] = new BackgroundWorker();
                bw[i].DoWork += CalculateSlow;
                bw[i].RunWorkerCompleted += GetAndShowResults;
                bw[i].RunWorkerAsync(input);
            }


        }


        private void CalculateSlow(object sender, DoWorkEventArgs args)
        {
            Threading.SlowMath sm = new Threading.SlowMath();
            args.Result = sm.Square((int)args.Argument);
        }

        private void GetAndShowResults(object sender, RunWorkerCompletedEventArgs args)
        { 
            lock (syncroot)
            {
                res += (int)args.Result;
                if (++numResults == 3)
                {
                    ResultTextBox.Text = res.ToString();
                }
            }
        }
    }
}

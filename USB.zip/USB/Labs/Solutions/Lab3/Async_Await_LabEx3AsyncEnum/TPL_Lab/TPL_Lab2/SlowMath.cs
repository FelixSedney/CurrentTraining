﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Threading
{
	class SlowMath
	{
		private Converter<int, int> _int2intDelegate;

		public SlowMath()
		{
			_int2intDelegate = Square;
		}


		public int Square(int n)
		{
			Thread.Sleep(3000);
			return n * n;
		}

        public Task<int> SquareAsync(int n)
        {
            Task<int> t = Task<int>.Run(() => Square(n));
            return t;
        }

        public async IAsyncEnumerable<int> SquareEnumeratorAsync(int [] values)
        {
            Task<int>[] tasks = new Task<int>[values.Length];
            for(int i = 0; i < values.Length; i++)
            {
                tasks[i] =  SquareAsync(values[i]);
            }
            for (int i = 0; i < tasks.Length; i++)
                yield return await tasks[i];
        }

		public IAsyncResult BeginSquare(int n, AsyncCallback callback, object state)
		{

			return _int2intDelegate.BeginInvoke(n, callback, state);
		}

		public int EndSquare(IAsyncResult ar)
		{
			return _int2intDelegate.EndInvoke(ar);
		}
	}
}

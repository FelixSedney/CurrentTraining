﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace _SemaphoreDemo
{
    class Program
    {

        static Semaphore _semaphore = new Semaphore(2, 2);
        static void Main(string[] args)
        {
            for (int i = 0; i < 4; i++)
            {
                Thread t = new Thread(new ThreadStart(MyMethod));
                t.Name = string.Format("Thread{0}", i);

                t.Start();

            }
            Console.ReadKey();

        }

        static void MyMethod()
        {
            _semaphore.WaitOne();
            Console.WriteLine("Thread{0} enter", Thread.CurrentThread.Name);
            Thread.Sleep(10);
            Console.WriteLine("Thread{0} Leave", Thread.CurrentThread.Name);
            _semaphore.Release();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace MonitorDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Worker worker = new Worker();
            Thread t1 = new Thread(new ThreadStart(worker.MethodA));
            Thread t2 = new Thread(new ThreadStart(worker.MethodB));

            t1.Start();
            t2.Start();
            t1.Join();
            t2.Join();
            Console.WriteLine();
            Console.WriteLine(worker.Counter);
            Console.WriteLine();
            Console.ReadKey();
        }
    }


    class Worker
    {
        public int Counter { get; set; }
        //monitor beschermt de code. MethodA en MethodB mogen nu nooit gelijktijdig uitgevoerd worden.
        public void MethodA()
        {


            {
                for (int i = 0; i < 1000; i++)
                {
                    Monitor.Enter(this);

                    int a = Counter;
                    Console.ForegroundColor = ConsoleColor.Red;
                    Counter = ++a;
                    Console.Write("{0} ", Counter);
                   Monitor.Exit(this);//moet in finally block
                }
            }
        }


        public void MethodB()
        {
            {
                for (int i = 0; i < 1000; i++)
                {
                 //   Monitor.Enter(this);
                    Counter = Counter - 1;
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.Write("{0} ", Counter);
                 //   Monitor.Exit(this);
                }
            }
        }
    }
}

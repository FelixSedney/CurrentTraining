﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace BarrierDemo
{
    class Calculator
    {
        private Barrier _barrier;
        public long Result { get; private set; }

        public Calculator()
        {
        }

        public Calculator(Barrier barrier)
        {
            _barrier = barrier;
        }

        public void Faculty(object o)
        {
            Console.WriteLine("entering method. {0}",Thread.CurrentThread.ManagedThreadId);

            int i = (int)o;
            Result = Fac(i);
            Console.WriteLine("Calculation completed. {0}", Thread.CurrentThread.ManagedThreadId);
            _barrier.SignalAndWait();
            Console.WriteLine("leaving method. {0}", Thread.CurrentThread.ManagedThreadId);

        }

        private long Fac(int i)
        {
            Thread.Sleep(200);
            if (i == 0 || i == 1)
            {
                return 1;
            }
            else
            {
                return i * Fac(i-1);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BarrierDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            const int TASK_COUNT = 3;

            Barrier barrier = new Barrier(TASK_COUNT);
            Calculator calc1 = new Calculator(barrier);
            Calculator calc2 = new Calculator(barrier);
            Thread t1 = new Thread(new ParameterizedThreadStart(calc1.Faculty));
            Thread t2 = new Thread(new ParameterizedThreadStart(calc2.Faculty));
            t1.Start(6);
            Thread.Sleep(2000);
            t2.Start(5);

            Console.WriteLine("Main thread is waiting {0}", Thread.CurrentThread.ManagedThreadId);            
            barrier.SignalAndWait();//main thread signals and waits. All three threads must signal and wait before next line is run.
            Console.WriteLine("All threads have signalled");
            Console.WriteLine(calc1.Result+calc2.Result);

            Console.WriteLine("done");
            Console.ReadKey();
        }
    }
}

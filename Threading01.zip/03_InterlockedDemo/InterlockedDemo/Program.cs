﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace InterlockedDemo
{
    class Program
    {

        static long x = 0;

        static void Main(string[] args)
        {
            Thread[] theThreads = new Thread[14];


            for (int i = 0; i < theThreads.Length; i++)
            {
                theThreads[i] = new Thread(DoWork);
            }

            for (int i = 0; i < theThreads.Length; i++)
            {
                
                theThreads[i].Start();
            }

            for (int i = 0; i < theThreads.Length; i++)
            {
                theThreads[i].Join();
            }

            Console.WriteLine(x);

            Console.ReadKey();
        }

        static void DoWork()
        {
            for (int i = 0; i < 100000; i++)
            {
               // x++;
                Interlocked.Increment(ref x);
                
            }
        }
    }
}

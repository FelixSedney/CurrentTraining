﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ManualResetEventDemo
{
    class Program
    {
        //static AutoResetEvent _re;//vergelijkbaar met een tourniquet
        static ManualResetEvent _re;//vergelijkbaar met een deur

        static void Main(string[] args)
        {
            //_re = new AutoResetEvent(false);
           _re = new ManualResetEvent(false);
            Thread t = new Thread(MethodA);
            t.Start();
            Thread t2 = new Thread(MethodB);
            t2.Start();
            Thread.Sleep(1500);
            _re.Set();//effect is afhankelij van het gebruik van manual/Auto 
          //  _re.Set();
            Console.WriteLine("DONE");
            Console.ReadKey();
        }

        static void MethodA()
        {
            Console.WriteLine("MethodA is waiting..");
            _re.WaitOne();
            Console.WriteLine("MethodA is released.");
        }

        static void MethodB()
        {
            Console.WriteLine("MethodB is waiting..");
            _re.WaitOne();
            Console.WriteLine("MethodB is released.");
        }
    }
}

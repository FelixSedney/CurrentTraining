﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace LockDemo2
{
    class Program
    {

        static void Main(string[] args)
        {
            Worker worker = new Worker();
            Thread t1 = new Thread(new ThreadStart(worker.MethodA));
            Thread t2 = new Thread(new ThreadStart(worker.MethodB));

            t1.Start();
            t2.Start();
            

            Console.ReadKey();
        }
    }
}

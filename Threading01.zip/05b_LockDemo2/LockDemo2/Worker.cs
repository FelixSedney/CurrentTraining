﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LockDemo2
{
    class Worker
    {
        public int Counter { get; set; }


        //lock beschermt de code. MethodA en MethodB mogen nu nooit gelijktijdig uitgevoerd worden.
        public void MethodA()
        {


            lock (this)
            {

                for (int i = 0; i < 1000; i++)
                {
                    Counter++;
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("{0} ", Counter);
                }
            }
        }


        public void MethodB()
        {
            lock (this)
            {
                for (int i = 0; i < 1000; i++)
                {
                //Counter--;
                int temp = Counter;
                temp--;
                Counter = temp;

                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.Write("{0} ", Counter);
                }
            }
        }
    }
}

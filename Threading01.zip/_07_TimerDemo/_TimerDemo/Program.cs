﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _TimerDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Threading.Timer timer = new System.Threading.Timer(new System.Threading.TimerCallback((x)=>Console.Write("-")), "-", 0, 1000);
            //System.Threading.Timer timer = new System.Threading.Timer(new System.Threading.TimerCallback(Progress), "-", 0, 1000);
            Console.WriteLine("DONE");
            Console.ReadKey();
        }

        static void Progress(object o)
        {
            Console.Write(o.ToString());
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CountDownEventDemo
{
    class Program
    {
        static CountdownEvent CountDown = new CountdownEvent(4);
        static void Main(string[] args)
        {
            //fork / join situation
            new Thread(() => SaySomething("I am Thread one.")).Start();
            new Thread(() => SaySomething("I am thread two.")).Start();
            new Thread(() => SaySomething("I am Thread Three.")).Start();
            Console.WriteLine("all threads waiting");
            for (int i = 0; i < 4; i++)//three threads and main thread
            {
                Console.WriteLine($"Calling Signal #{i}");
                CountDown.Signal();
                Thread.Sleep(1000);
            }
            Console.WriteLine("Done");

            Console.ReadKey();
            //CountDown.Reset();
        }

        static void SaySomething(string Something)
        {
            Console.WriteLine($"-->{Something} ");
            CountDown.Wait();//wait for counter to reach 0
            Console.WriteLine($"{Something} -->");
        }

       
    }
}

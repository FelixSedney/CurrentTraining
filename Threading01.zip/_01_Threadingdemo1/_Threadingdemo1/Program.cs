﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace _Threadingdemo1
{
    class Program
    {
        static Mutex _mutex = new Mutex();//Mutual exclusive
        static void Main(string[] args)
        {
            Thread t1 = new Thread(new ParameterizedThreadStart(WriteX));//by default background thread
            t1.IsBackground = true;
            Thread t2 = new Thread(new ParameterizedThreadStart(WriteX));
            t2.IsBackground = true;
            t1.Start(ConsoleColor.Cyan);
            t2.Start(ConsoleColor.Yellow);
            Console.WriteLine("DONE");
            Console.ReadKey();
        }

        static void WriteX(object consoleColor)
        {

            for (int i = 0; i < 10000; i++)
            {
                try
                {
                    _mutex.WaitOne();
                    Console.ForegroundColor = (ConsoleColor)consoleColor;
                    Console.Write($"{i}X ");
                }
                finally
                {
                    _mutex.ReleaseMutex();
                }
            }

            _mutex.Dispose();//using(){}
        }
    }
}
//mutex, foreground, background, join
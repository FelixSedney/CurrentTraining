﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExtensionMethodsDemo
{
   public static class MyExtensions
    {
    public    static int WordCount(this string s)//extension on string
        {
            string[] result = s.Split(" ");
            return result.Length;
        }
    }
}

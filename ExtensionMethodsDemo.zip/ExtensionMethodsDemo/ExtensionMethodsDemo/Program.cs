﻿using System;

namespace ExtensionMethodsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = "lkjf gfker k;ejr rekjtkerj erker";
            Console.WriteLine(s.WordCount());
            
        }

        //static int WordCount(string s)
        //{
        //    string[] result = s.Split(" ");
        //    return result.Length;
        //}
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace DAL
{
    //The configuration for an owned type needs to be done in the OwnsOne/OwnsMany API calls of the entity type that owns it.
    //It is not currently possible to have a separate IEntityTypeConfiguration for an owned type.Doing so causes 
    //    EF to configure it as a normal, non-owned entity type.
    public class BlogDetailsConfiguration : IEntityTypeConfiguration<BlogDetail>
    {
        public void Configure(EntityTypeBuilder<BlogDetail> builder)
        {
            builder.Property(p => p.Url)
                .HasColumnName("URI");
        }
    }
}

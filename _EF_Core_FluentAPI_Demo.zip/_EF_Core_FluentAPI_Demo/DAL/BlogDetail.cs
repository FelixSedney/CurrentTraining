﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DAL
{
  public  class BlogDetail
    {
        //[MaxLength(41)]
        public string Url { get; set; }
        public int Rating { get; set; }

    }
}

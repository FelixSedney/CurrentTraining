﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace DAL
{
    class BlogConfiguration : IEntityTypeConfiguration<Blog>
    {


        public void Configure(EntityTypeBuilder<Blog> builder)
        {
            // base.OnModelCreating(modelBuilder);
            builder.HasKey(p => p.BlogRef);
            builder.Property(p => p.Name)
                .HasMaxLength(40)
                .IsRequired();
            
            builder.OwnsOne(b=>b.BlogDetails)
                .Property("Url")
                .HasMaxLength(42);

            
        }


    }
}

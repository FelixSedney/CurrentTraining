﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DAL
{
    public class Blog
    {
        public int BlogRef { get; set; }
        public string Name { get; set; }
        //public string Url { get; set; }
        //public int Rating { get; set; }
        public BlogDetails BlogDetails { get; set; }

        public override string ToString()
        {
            return $"{BlogRef}\t{Name}\t{BlogDetails.Url}\t{BlogDetails.Rating}";
        }
    }
}
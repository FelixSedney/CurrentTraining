﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace DAL
{
  public  class BlogDetails
    {
        public string Url { get; set; }
        public int Rating { get; set; }

    }
}

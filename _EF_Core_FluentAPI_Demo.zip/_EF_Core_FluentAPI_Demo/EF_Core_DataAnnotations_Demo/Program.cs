﻿using DAL;
using System;
using System.Linq;

namespace EF_Core_FluentAPI_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            using (BlogContext context = new BlogContext())
            {
                context.Database.EnsureDeleted();
                context.Database.EnsureCreated();
                var result = context.Blogs.FirstOrDefault(b => b.Name == "BlogA");
                if (result == null)
                {
                    context.Blogs.Add(new Blog() { Name = "BlogA", BlogDetails = new BlogDetails() { Url = "https://BlogA", Rating = 3 } });
                    context.Blogs.Add(new Blog() { Name = "BlogB", BlogDetails = new BlogDetails() { Url = "https://BlogB", Rating = 5 } });
                }
                context.SaveChanges();
            }

            using (BlogContext context = new BlogContext())
            {
                foreach (var item in context.Blogs)
                {
                    Console.WriteLine(item);
                }
            }
        }
    }
}

﻿using DAL;
using DomainClasses;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace _EF_Core_NoSql
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Seeding database");
            using (BlogContext context = new BlogContext())
            {
                context.Database.EnsureDeleted();
                context.Database.EnsureCreated();
                Blog newBlog = new Blog() { BlogID = 1, Title = "BlogA", Posts = new List<Post>() };
                Post post1 = new Post() { PostId = 1, Content = "Post1 of BlogA" };
                Post post2 = new Post() { PostId = 2, Content = "Post2 of BlogA" };
                newBlog.Posts.Add(post1);
                newBlog.Posts.Add(post2);
                context.Blogs.Add(newBlog);
                //context.Posts.AddRange(new List<Post>() { post1, post2 });
                Blog BlogB = new Blog() { BlogID = 2, Title = "BlogB", Posts = new List<Post>() };
                Post post01 = new Post() { PostId = 3, Content = "Post01 of BlogB" };
                Post post02 = new Post() { PostId = 4, Content = "Post02 of BlogB" };
                BlogB.Posts.Add(post01);
                BlogB.Posts.Add(post02);
                context.Blogs.Add(BlogB);
                //context.Posts.AddRange(new List<Post>() { post01, post02 });
                context.SaveChanges();
            }
            Console.WriteLine("Changes saved");

            Console.WriteLine("Getting Blogs and Posts from dB.");
            ////als je blogs en posts op deze manier wil organiseren dan moet je de Posts [Owned] maken.
            //using (BlogContext context = new BlogContext())
            //{
            //    foreach (var blog in context.Blogs)
            //    {
            //        Console.WriteLine(blog.Title);
            //        foreach (var post in blog.Posts)
            //        {
            //            Console.WriteLine($"\t{post.Content}");
            //        }
            //    }
            //}

            //Als Posts niet [Owned] is dan moet je het combineren van Blogs en Posts zelf uitschrijven.
            using (BlogContext context = new BlogContext())
            {
                foreach (var blog in context.Blogs)
                {
                    Console.WriteLine(blog.Title);
                    foreach (var post in context.Posts.ToList().Where(p=>p.BlogId==blog.BlogID))
                    {
                        Console.WriteLine($"\t{post.Content}");
                    }
                }
            }

            Console.WriteLine("DONE");
        }
    }
}

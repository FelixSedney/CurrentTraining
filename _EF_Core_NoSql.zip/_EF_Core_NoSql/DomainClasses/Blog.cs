﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DomainClasses
{
    public class Blog
    {
        public int BlogID { get; set; }
        public string Title { get; set; }
        public ICollection<Post> Posts { get; set; }

        public override string? ToString()
        {
            return $"{Title}";
        }
    }
}



﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace DomainClasses
{
    //[Owned]
    public class Post
    {
        public int PostId { get; set; }
        public string Content { get; set; }
        public Blog Blog { get; set; }
        public int BlogId { get; set; }

        public override string? ToString()
        {
            return $"{Content}";
        }
    }

}

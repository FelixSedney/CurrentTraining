﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParallelInvokeDemo
{
    class Program
    {
        static void Main(string[] args)
        {
           //Task[] tasks= {
           //                  new Task(()=>write("X",ConsoleColor.Cyan)),
           //                  new Task(()=>write("_",ConsoleColor.Yellow)),
           //                  new Task(()=>write("^",ConsoleColor.Green))
           //              };
           //foreach (Task task in tasks)
           //{
           //    task.Start();
           //}

           //Task.WaitAll(tasks);
           //Console.ForegroundColor = ConsoleColor.White;

            Parallel.Invoke(() => write("X", ConsoleColor.Cyan),() => write("_", ConsoleColor.Yellow),() => write("^", ConsoleColor.Green));
           Console.WriteLine("D O N E");
            Console.ReadKey();
        }

        static void write(string s,ConsoleColor cc)
        {
            for (int i = 0; i < 1000; i++)
            {
                Console.ForegroundColor = cc;
                Console.Write("{0}{1}",i,s);
            }
        }
    }
}

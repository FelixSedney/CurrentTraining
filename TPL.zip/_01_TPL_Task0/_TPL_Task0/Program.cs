﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _TPL_Task0
{
    class Program
    {
        static void Main(string[] args)
        {
            //by default BACKGROUND threads

            Task t1 = new Task(() => Console.WriteLine("running task 1"));
            t1.Start();
            Console.WriteLine("t1 done");


            Console.ReadKey();

            Task t2 = Task.Run(() => Console.WriteLine("running task 2"));
            Console.WriteLine("t2 done");

            Console.ReadKey();

            Task t2a = Task.Factory.StartNew(() => Console.WriteLine("running task 12a"));
            Console.WriteLine("t2a done");

            Console.ReadKey();

            Task<long> t3 = new Task<long>(() => 10 * 10);
            t3.Start();
            Console.WriteLine(t3.Result);//Blocking call
            Console.WriteLine("t3 done");
            Console.ReadKey();

  
        }
    }
}

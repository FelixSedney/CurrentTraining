﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LazyInitializationDemo
{
   public static class Orders
    {
        private static  List<Order> _items = new List<Order>()
        {
            new Order() { OrderID = 101, Product = "Frame", Quantity = 100,CustomerID=1 },
            new Order() { OrderID = 102, Product = "Rail", Quantity = 10,CustomerID=1 },
        };

        public static List<Order> GetItems()
        {
            return _items;
        }
    }
}

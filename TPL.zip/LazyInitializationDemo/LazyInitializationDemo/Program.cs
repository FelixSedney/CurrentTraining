﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LazyInitializationDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer c1 = new Customer()
            {
                Name = "Bas Partout",
                CustomerID = 1,
                //Orders worden evt uit een andere bron gehaald.
               
            };



            Console.WriteLine(c1.Name);
            foreach (var item in c1.OrderItems)
            {
                Console.WriteLine(item.OrderID);
            }
            Console.ReadKey();
        }
    }
}

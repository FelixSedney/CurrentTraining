﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LazyInitializationDemo
{
    public class Customer
    {
        
        private  Lazy<List<Order>> _orders = new Lazy<List<Order>>(GetMyOrders);

        private static List<Order> GetMyOrders()
        {
            return Orders.GetItems();
        }

        public string Name { get; set; }
        public int CustomerID { get; set; }

        public List<Order> OrderItems
        {
            get { return _orders.Value; }
        }


    }
}

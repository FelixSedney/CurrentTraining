﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TaskCancellationDemo
{
    public partial class Form1 : Form
    {
        CancellationTokenSource _cts;// = new CancellationTokenSource();
        public Form1()
        {
            InitializeComponent();
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            _cts.Cancel();
            _cts.Dispose();//er is geen reset voor de cancelation token
        }

        private void StartButton_Click(object sender, EventArgs e)
        {
            _cts = new CancellationTokenSource();
            CancellationToken token = _cts.Token;
            
            bool nextIteration = true;
            Task t1 = Task.Factory.StartNew(() =>
                {
                    do
                    {
                        if (progressBar1.Value >= progressBar1.Maximum)
                        {
                            progressBar1.Invoke(new Action(() => progressBar1.Value = 0));
                        }
                        progressBar1.Invoke(new Action(() => progressBar1.Value += 10));
                        if (token.IsCancellationRequested)
                        {
                            //token.ThrowIfCancellationRequested();
                            nextIteration=false;
                        }
                        Thread.Sleep(200);
                    }
                    while (nextIteration);
                },token);
        }        
    }    
}

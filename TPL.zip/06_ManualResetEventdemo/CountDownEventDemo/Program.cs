﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CountDownEventDemo
{
    class Program
    {
        //static ManualResetEvent mre = new ManualResetEvent(false);
        static AutoResetEvent mre = new AutoResetEvent(false);//nu drie keer SET aanroepen
        static void Main(string[] args)
        {
           
            new Task(() => SaySomething("I am Thread one.")).Start();
            new Task(() => SaySomething("I am Thread two.")).Start();
            new Task(() => SaySomething("I am Thread three.")).Start();

            Console.WriteLine("all threads waiting");
            //Thread.Sleep(1000);
            Thread.SpinWait(1000000000);//lightwait Sleep variant. Parameter is geen tijd oid
            Console.WriteLine("calling set");
            mre.Set();
            //for (int i = 0; i < 4; i++)
            //{
            //    Console.WriteLine("Calling Signal #{0}", i);
            //    mre.Set();
            //    Thread.Sleep(1000);
            //}
            Console.WriteLine("Done");

            Console.ReadKey();
        }

        static void SaySomething(string Something)
        {
            mre.WaitOne();
            Console.WriteLine(Something);
        }

       
    }
}

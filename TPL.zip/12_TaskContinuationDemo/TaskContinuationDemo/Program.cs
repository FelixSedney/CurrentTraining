﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TaskContinuationDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Task t1 = Task.Factory.StartNew(() =>
            {
                Thread.Sleep(100);
                Console.WriteLine("running task 1");
                Thread.Sleep(2000);
            });
            Console.WriteLine("in between");
            Task t2 = t1.ContinueWith((prevTask) =>
                {
                    Console.WriteLine("task 1 completed. Running task 2");
                });
           
            Console.WriteLine("done");

            Console.ReadKey();
        }
    }
}
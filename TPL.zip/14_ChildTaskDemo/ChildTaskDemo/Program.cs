﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ChildTaskDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Task<int> t1 = Task<int>.Factory.StartNew(() =>
                    {
                        Console.WriteLine("starting task 1");
                        Thread.Sleep(100);
                        Task<int> t2 = Task<int>.Factory.StartNew(() =>
                            {
                                Console.WriteLine("starting child task");
                                Task.Delay(2000);
                                Console.WriteLine("ending child task");
                                return 10;
                            });//varieren met/zonder ,TaskCreationOptions.AttachedToParent

                        //Console.WriteLine("Result child {0}",t2.Result);//blocking call
                        return 0;
                    }
                    );
                Console.WriteLine("Tasks created and running ....");
                Console.WriteLine("Result parent {0}", t1.Result);//blocking
            }
            catch (AggregateException ex)
            {
                Console.WriteLine(ex.Message);
                foreach (var item in ex.InnerExceptions)
                {
                    Console.WriteLine(item.Message);
                }
            };

            Console.WriteLine("done");

            Console.ReadKey();
            //run multiple times. Output may vary
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            StatusTextBlock.Text += "StartButtonClicked ";//on main thread
            Task[] tasks = new Task[]  
            {
                //array of two tasks
                new Task(()=>
                {
                    for (int i = 0; i < 50; i++)	
                    {
                        pb1.Dispatcher.Invoke(() => pb1.Value += 10);
                        Thread.Sleep(120);
			        }
                   }),
                new Task(()=>{for (int i = 0; i < 50; i++)
                {
                    pb2.Dispatcher.Invoke(()=>pb2.Value+=10);
                    Thread.Sleep(100);
			    }
              })
            };
            //start the tasks
            foreach (var task in tasks)
            {
                task.Start();
            }
            //wait for all tasks to end.
            //Task.WhenAll(tasks).ContinueWith((x) => StatusTextBlock.Dispatcher.Invoke(() => StatusTextBlock.Text += "READY"));
            //wait for a tasks to end.
            Task.WhenAny(tasks).ContinueWith((x) => StatusTextBlock.Dispatcher.Invoke(() => StatusTextBlock.Text += "READY"));
            //Task.WhenAny(tasks).ContinueWith((n) => StatusTextBlock.Text += "READY");

            StatusTextBlock.Text += " DONE ";//on main thread
        }
    }
}

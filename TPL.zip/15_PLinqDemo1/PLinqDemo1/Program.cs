﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PLinqDemo1
{
    class Program
    {
        static int[] arr = new int[10000];
        static void Main(string[] args)
        {
            
            Random rnd = new Random();
            //Vul array met 10000 random waarden. Doe dit in parallel.
            Parallel.For(0, 10000, (int i) => arr[i] = rnd.Next(1, 100000));

            var evenNumbers = (from item in arr.AsParallel()
                               where (item % 2) == 0
                               //orderby item
                               select item).ToList<int>();

            //Als je heel goed zoekt, dan is vast te stellen dat de volgorde varieert tgv parallel
           // Parallel.For(0, evenNumbers.Count, (n) => Console.Write("{0} ",evenNumbers[ n]));

            //for (int i = 0; i < evenNumbers.Count; i++)
            //{
            //    Console.Write("{0} ", evenNumbers[i]);
            //}
            Console.WriteLine();
            for (int i = 0; i < evenNumbers.Count - 1; i++)
            {
                if (evenNumbers[i] > evenNumbers[i + 1])
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                }
                Console.Write("{0} ", evenNumbers[i]);
                Console.ForegroundColor = ConsoleColor.White;

            }

            Console.ReadKey();
        }


    }
}


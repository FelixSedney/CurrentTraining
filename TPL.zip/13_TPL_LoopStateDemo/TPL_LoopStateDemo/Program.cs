﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPL_LoopStateDemo
{//Demo in host!!
    class Program
    {



        static void Main(string[] args)
        {
            List<char> result = new List<char>();

            Parallel.ForEach("abcd efgh ijklm nopq rstuvw xyz123, 456789 ABCD, EFGH IJKLM, NOPQR STUVW, !@#$%^&*()_+", (c, loopState) =>
                {
                    if (c == ',')
                    { loopState.Stop(); }
                    else
                    {
                        Console.Write(c);
                        result.Add(c);
                    }
                }
                );
            Console.WriteLine();
            result.OrderBy(c=>c).ToList().ForEach(c => Console.Write(c));
            Console.ReadKey();
        }


    }
}


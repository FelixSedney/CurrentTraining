﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _ParallelInvokeDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("READY");
            Console.ReadKey();
        }

        static void WriteX(string s,ConsoleColor cc)
        {
            for (int i = 0; i < 1000; i++)
            {
                Console.ForegroundColor = cc;
                Console.Write(s);
            }
        }
    }
}

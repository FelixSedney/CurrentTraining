﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace _ParallelInvokeDemo
{
    class Program
    {
        static Mutex _mutex = new Mutex();
        static void Main(string[] args)
        {
            Task[] tasks =
            {
                new Task(()=>WriteChar("*",ConsoleColor.Cyan)),
                new Task(()=>WriteChar("_",ConsoleColor.Yellow)),
                new Task(()=>WriteChar("#",ConsoleColor.Green)),
            };
            foreach (var task in tasks)
            {
                task.Start();
            }

            Task.WaitAny(tasks);
            //Task.WaitAll(tasks);

            Console.WriteLine("READY");
            Console.ReadKey();
        }

        static void WriteChar(string s,ConsoleColor cc)
        {
            for (int i = 0; i < 1000; i++)
            {
                _mutex.WaitOne();
                Console.ForegroundColor = cc;
                Console.Write(s);
                _mutex.ReleaseMutex();
            }
        }
    }
}
//task
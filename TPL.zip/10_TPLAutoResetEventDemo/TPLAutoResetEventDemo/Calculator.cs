﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace TPLAutoResetEventDemo
{
    class Calculator
    {
        private AutoResetEvent _are;
        public long Result { get; private set; }

        public Calculator()
        {
        }

        public Calculator(AutoResetEvent are)
        {
            _are = are;
        }

        public void Faculty(object o)
        {
            int i = (int)o;
            Result = Fac(i);
            _are.Set();
        }

        private long Fac(int i)
        {
            Thread.Sleep(100);
            if (i == 0 || i == 1)
            {
                return 1;
            }
            else
            {
                return i * Fac(i-1);
            }
        }
    }
}

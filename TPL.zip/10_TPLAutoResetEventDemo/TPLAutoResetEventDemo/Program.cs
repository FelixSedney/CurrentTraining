﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TPLAutoResetEventDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            AutoResetEvent are = new AutoResetEvent(false);
            Calculator calc1 = new Calculator(are);
            Calculator calc2 = new Calculator(are);

            Task task1 = new Task(new Action<object>(calc1.Faculty), 5);
            Task task2 = new Task(new Action<object>(calc2.Faculty), 6);
            task1.Start();
            task2.Start();

            are.WaitOne();
            are.WaitOne();
            Console.WriteLine(calc2.Result+calc1.Result);

            Console.ReadKey();
        }
    }
}

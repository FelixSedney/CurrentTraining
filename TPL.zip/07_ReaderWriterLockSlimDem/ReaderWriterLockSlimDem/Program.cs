﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ReaderWriterLockSlimDemo
{
    class Program
    {
        static ReaderWriterLockSlim _rwls;
        static List<long> _items;
        static void Main(string[] args)
        {
            _rwls = new ReaderWriterLockSlim(LockRecursionPolicy.SupportsRecursion);
            //meerdere readers toegestaan, maar geen writer als er ook readers data lezen
            Random rnd = new Random();
            _items = new List<long>(){ 
                rnd.Next(4,10),rnd.Next(4,10),
                rnd.Next(4,10),rnd.Next(4,10),rnd.Next(4,10)

            };//list is gevuld met random waarden tussen 4 en 10
            Task task1 = new Task(ItemReader);
            Task task2 = new Task(ItemWriter);//
            Task task3 = new Task(ItemReader);
            Task task4 = new Task(ItemReader);


            task1.Start();//start een reader
            task4.Start();//start een reader
            Thread.Sleep(100);
            task2.Start();//start writer. moet echter op readers wachten
            Thread.Sleep(3000);//wacht om writer gelegenheid te geven om toegang te krijgen.
            task3.Start();
            Console.ReadKey();

        }

        static void ItemWriter()
        {
            Calculator calc = new Calculator();
            try
            {
                while (_rwls.TryEnterWriteLock(50) == false)
                {
                    Console.Write(".");
                    Thread.Sleep(1);
                }
                Console.WriteLine("writer enter");

                for (int i = 0; i < _items.Count; i++)
                {
                    _items[i] = calc.Fac(_items[i]);//vervang het getal door zijn faculteit
                }
            }
            finally
            {
                _rwls.ExitWriteLock();
                Console.WriteLine("\texit write");
            }
        }

        static void ItemReader()
        {
            Console.WriteLine("Reader Enter");
            try
            {
                _rwls.EnterReadLock();
                _items.ForEach((l) => { Console.Write($"{l}\t"); Thread.Sleep(300); });//wat staat er in de list
            }
            finally
            {
                Console.WriteLine("\tReader Leave");
                _rwls.ExitReadLock();
            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ReaderWriterLockSlimDemo
{
    class Calculator
    {

        public long Result { get; set; }

        public Calculator()
        {
        }

        


        public long Fac(long i)
        {
            if (i == 0 || i == 1)
            {
                return 1;
            }
            else
            {
                return i * Fac(i-1);
            }
        }
    }
}

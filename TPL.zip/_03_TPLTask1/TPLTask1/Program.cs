﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPLTask1
{
    class Program
    {
        static int[] arr = new int[10000];
        static void Main(string[] args)
        {
            int largest;
            Random rnd=new Random();
            //Vul array met 10000 random waarden. Doe dit in parallel.
            Parallel.For(0, 10000, (i) => arr[i] = rnd.Next(1, 15000));//in principe worden meerdere threads belast met het vullen van de array

            //Twee taken bepalen ieder grootste getal in een deel van de array.
            Task<int> task1 = new Task<int>(() => ProcessSegment(0, 5000));
            Task<int> task2 = new Task<int>(() => ProcessSegment( 5000,10000));
            task1.Start();
            task2.Start();

            if (task1.Result > task2.Result)
            {
                largest = task1.Result;
            }
            else
            {
                largest = task2.Result;
            }
           Console.WriteLine(largest);

            Console.ReadKey();
        }

        static int ProcessSegment(int lower, int upper)
        {
            int largest=0;
            Parallel.For(lower, upper, (n) => { if (arr[n] > largest) { largest = arr[n]; } });
            
            return largest;
        }
    }
}

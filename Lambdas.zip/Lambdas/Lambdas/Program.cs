﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Lambdas
{
    class Program
    {
        
        static void Main(string[] args)
        {
           
            List<string> cities = new List<string>() { "Veenendaal", "Ede", "Wageningen", "Doorn", "Zeist", "Maarn" };
            
            var result = cities.Where(  s => s.Length < 6);//lambda expression
            //var result = cities.Where( ( s) => s.Length < 6);//lambda expression
            //var result = cities.Where( (string s) => s.Length < 6);//lambda expression
            //var result = cities.Where( (string s) =>{ return s.Length < 6; });//lambda expression
            //var result = cities.Where(delegate (string s) { return s.Length < 6; });//anonymous method
            //var result = cities.Where(IsShort);

            foreach (var city in result)
            {
                Console.WriteLine(city);
            }
           
            Console.ReadKey();
        }

        static bool IsShort(string s)
        {
            return s.Length < 6;
        }
    
    }
}

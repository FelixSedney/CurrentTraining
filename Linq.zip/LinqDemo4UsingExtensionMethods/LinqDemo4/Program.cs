﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinqDemo4
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Person> Beatles = new List<Person>()
            {
               new Person("Paul","Liverpool"){Instruments=new List<string>(){"Bass","Guitar","Vocals"}},
                new Person("John","New York"){Instruments=new List<string>(){"Piano","Guitar","Vocals"}}, 
                new Person("George","Liverpool"){Instruments=new List<string>(){"Guitar","Vocals"}},
                new Person("Ringo","Los Angeles"){Instruments=new List<string>(){"Drums","Vocals"}}
            };

            var result2=from b in Beatles
                        group b by b.Address into citizens
                        where citizens.Count()>1
                        select citizens;

            
            foreach (var item in result2)
            {
                Console.WriteLine(item.Key);
                foreach (var x in item)
                {
                    Console.WriteLine("\t"+x.Name);
                }
            }

            Console.ReadKey();

            List<Person> Stones = new List<Person>()
            {
      new Person()  {Name = "Mik", Address = "Sheffield"}, 
      new Person()  {Name = "Keith", Address = "London"}, 
      new Person()  {Name = "Charlie", Address = "Liverpool"}, 
      new Person()  {Name = "Ron", Address = "Sheffield"} 
            };

            //var result = from b in Beatles
            //             join st in Stones on b.Address equals st.Address
            //             select new {Beatle= b,Stone= st };

            var result = Beatles.Join(Stones, (Person x) => x.Address, (Person st) => st.Address, (Person x,Person st) => new {x, st });

            foreach (var item in result)
            {
                Console.WriteLine(item.st.Name+"\t"+item.x.Name);
            }
            //foreach (var item in result)
            //{
            //    Console.WriteLine(item.Beatle.Name +"\t"+item.Stone.Name);
            //}
           

            Console.ReadKey();

            //geeft alle beatles ook als er geen matching RollingStone is.
            //Om foutmelding te voorkomen de constructie bij de stones.
            //var result3 = from b in Beatles
            //             join st in Stones on b.Address equals st.Address into stonelist
            //             from stone in stonelist.DefaultIfEmpty()
            //             select new { Beatle = b, Stone = stone };

            var result3=Beatles.GroupJoin(Stones,b=>b.Address,st=>st.Address,(bs,sts)=>new {bs,St=sts.FirstOrDefault()});
            foreach (var item in result3)
            {
                Console.WriteLine(item.bs.Name);
                Console.WriteLine(item.St == null ? "-" : item.St.Name);
            }


            Console.WriteLine();
            //foreach (var item in result3)
            //{
            //    Console.WriteLine(item.Beatle.Name);
            //    Console.WriteLine(item.Stone==null?"-":item.Stone.Name);
            //}

            Console.ReadKey();

        
        }
    }
}

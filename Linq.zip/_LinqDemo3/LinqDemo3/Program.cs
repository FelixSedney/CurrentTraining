﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinqDemo3
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Person> Beatles = new List<Person>()
            {
               new Person("Paul","Liverpool"){Instruments=new List<string>(){"Bass","Guitar","Vocals"}},
                new Person("John","New York"){Instruments=new List<string>(){"Piano","Guitar","Vocals"}}, 
                new Person("George","Liverpool"){Instruments=new List<string>(){"Guitar","Vocals"}},
                new Person("Ringo","Los Angeles"){Instruments=new List<string>(){"Drums","Vocals"}}
            };
            //var result = from beatle in Beatles
            //             from instrument in beatle.Instruments
            //             where instrument == "Guitar"
            //             select beatle;

            var result = Beatles.Where(b => b.Instruments.Contains("Guitar"));

            foreach (var beatle in result)
            {
                Console.WriteLine(beatle.Name);
            }
          

            Console.ReadKey();

            //var result2 = from beatle in Beatles
            //              let numberOfInstruments = beatle.Instruments.Count
            //              where numberOfInstruments < 3
            //              select new { beatle.Name, NumberOfInstruments =numberOfInstruments };

            var result2 = Beatles.Where(b => b.Instruments.Count < 3).Select(b => new { b.Name, NumberOfInstruments = b.Instruments.Count });
            foreach (var beatle in result2)
            {
                Console.WriteLine($"{beatle.Name}\t{beatle.NumberOfInstruments}");
            }

            Console.ReadKey();

        }
    }
}

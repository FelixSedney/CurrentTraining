﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinqDemo2
{
    class Program
    {
        static void Main(string[] args)
        {

            List<Person> band = new List<Person>() 
            { 
                new Person("Paul",40),
                 new Person("John",42), 
                new Person("George",44), 
                new Person("Ringo",42) 
            };

            //var result = from person in band
            //             select new { Email = $"{person.Name}@Beatles.uk", person.Age };

            var result = band.Select(p => new { Email = $"{p.Name}@Beatles.uk", p.Age });

            foreach (var person in result)
            {
                Console.WriteLine($"{person.Age}\t{person.Email}");
            }

            Console.ReadKey();

            //var result2 = from person in band
            //              group person by person.Age;
            var result2 = band.GroupBy(p => p.Age);

            foreach (var personGroup in result2)
            {
                Console.WriteLine(personGroup.Key);
                foreach (var person in personGroup)
                {
                    Console.WriteLine($"\t{person.Name}");
                }
            }

         

            Console.ReadKey();

        }
    }
}

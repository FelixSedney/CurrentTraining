﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinqDemo4
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Person> Beatles = new List<Person>()
            {
               new Person("Paul","Liverpool"){Instruments=new List<string>(){"Bass","Guitar","Vocals"}},
                new Person("John","New York"){Instruments=new List<string>(){"Piano","Guitar","Vocals"}}, 
                new Person("George","Liverpool"){Instruments=new List<string>(){"Guitar","Vocals"}},
                new Person("Ringo","Los Angeles"){Instruments=new List<string>(){"Drums","Vocals"}}
            };
            //var result = from beatle in Beatles
            //             group beatle by beatle.Address into citizens
            //             where citizens.Count() > 1
            //             select citizens;

            var result = Beatles.GroupBy(b => b.Address).Where(x => x.Count() > 1);

            foreach (var personGroup in result)
            {
                Console.WriteLine(personGroup.Key);
                foreach (var person in personGroup)
                {
                    Console.WriteLine($"\t{person.Name}");
                }
            }


            Console.ReadKey();

            List<Person> Stones = new List<Person>()
            {
      new Person()  {Name = "Mik", Address = "Sheffield"}, 
      new Person()  {Name = "Keith", Address = "London"}, 
      new Person()  {Name = "Charlie", Address = "Liverpool"}, 
      new Person()  {Name = "Ron", Address = "Sheffield"} 
            };

            //var result2 = from beatle in Beatles
            //              join stone in Stones on beatle.Address equals stone.Address
            //              select new { Beatle = beatle, Stone = stone };

            var result2 = Beatles.Join(Stones, b => b.Address, s => s.Address, (b, s) => new { Beatle = b, Stone = s });

            foreach (var item in result2)
            {
                Console.WriteLine($"{item.Beatle.Name}\t{item.Stone.Name}");
            }

            Console.ReadKey();

            //geeft alle beatles ook als er geen matching RollingStone is.
            //Om foutmelding te voorkomen de constructie bij de stones.

            var result3 = from beatle in Beatles
                          join stone in Stones on beatle.Address equals stone.Address into stonelist
                          //from stoneMember in stonelist.DefaultIfEmpty()
                          //select new { Beatle = beatle, RollingStone = (stoneMember == null) ? new Person() : stoneMember };
                          select new { Beatle = beatle, RollingStones = stonelist };

            //var result3 = Beatles.GroupJoin(Stones, b => b.Address, s => s.Address, (b, s) => new { Beatle = b, RollingStone = s.FirstOrDefault() });

            foreach (var item in result3)
            {
                ////Console.WriteLine($"{item.Beatle.Name}\t{item.RollingStone.Name");
                //Console.Write($"{item.Beatle.Name}\t");
                
                //    Console.WriteLine(item.RollingStone?.Name);
                

            }


            Console.ReadKey();

        }
    }
}

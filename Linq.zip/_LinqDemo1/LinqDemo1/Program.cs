﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinqDemo1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Person> band = new List<Person>() 
            { 
                new Person("Paul"),
                 new Person("John"), 
                new Person("George"), 
                new Person("Ringo") 
            };

            var result = band.Where(p => p.Name.Length < 5)
                .OrderBy(p => p.Name)
                .Select(p=>p.Name);

            band.Add(new Person("Joko"));

            foreach (var name in result)
            {
                Console.WriteLine(name);
            }

            Console.ReadKey();

            var result2 = (from person in band
                          where person.Name.Length < 5
                          orderby person.Name
                          select person).ToList();

            foreach (var person in result2)
            {
                Console.WriteLine($"{person.Name}\t{person.Age}");
            }

           



            Console.ReadKey();

            string filter= "n";
            //var result3 = from person in band
            //              where person.Name.Contains(filter)
            //              select person;
             band.Where(p => p.Name.Contains(filter))
                .ToList()
                .ForEach(p=>Console.WriteLine(p.Name));
            filter = "o";

            //foreach (var person in result3)
            //{
            //    Console.WriteLine($"{person.Name}\t{person.Age}");
            //}

            Console.ReadKey();
        }
    }
}

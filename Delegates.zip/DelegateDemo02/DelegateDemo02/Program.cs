﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo02
{
    class Program
    {
        delegate bool ComparePerson(Person p, Person q);//1
        static void Main(string[] args)
        {
            Person[] persons =
            {
                new Person("gerard",35),
                new Person("vera",18),
                new Person("edward",21),
                new Person("helma",15)
            };
            foreach (var person in persons)
            {
                Console.WriteLine(person);
            }
            Console.WriteLine();
            Console.Write("Do you want to sort by [N]ame or by [A]ge ?  ");
            string reply = Console.ReadLine();
            ComparePerson cp = null;
            if (reply.ToUpper() == "N")
            {
                cp = new ComparePerson(CompareString);
            }
            else
            {
                cp = new ComparePerson(CompareInt);
            }

            

            for (int j = 0; j < persons.Length - 1; j++)
            {
                for (int i = 0; i < persons.Length - 1; i++)
                {
                    if (cp( persons[i], persons[i + 1]))
                    {
                        Person temp = persons[i];
                        persons[i] = persons[i + 1];
                        persons[i + 1] = temp;
                    }
                }
            }


            foreach (var person in persons)
            {
                Console.WriteLine(person);
            }

            Console.WriteLine("DONE");
            Console.ReadKey();
        }

        static bool CompareInt(Person p, Person q)
        {
            return p.Age > q.Age;
        }

        static bool CompareString(Person p, Person q)
        {
            if (p.Name.CompareTo(q.Name) > 0)
            {
                return true;
            }
            return false;
        }
    }
}

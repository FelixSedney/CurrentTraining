﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateAndEvents
{
 public   class Sensor
    {

        public delegate void Speed2High(object sender, SpeedEventArgs e);
        public event Speed2High SpeedToHigh;
        public string Name { get; set; }
        public int Threshold { get; set; }

        private int _speed;

        public int Speed
        {
            get { return _speed; }
            set {
                if (value > Threshold)
                {
                    SpeedToHigh.Invoke(this, new SpeedEventArgs(value));
                }
                _speed = value; 
            }
        }

        public Sensor(string name,int threshold)
        {
            Name = name;
            Threshold = threshold;
        }

    }
}

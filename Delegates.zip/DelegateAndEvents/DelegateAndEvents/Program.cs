﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateAndEvents
{
    class Program
    {
        static void Main(string[] args)
        {
            Sensor s1 = new Sensor("s1", 85);
            Display d1 = new Display("d1");
            
            s1.SpeedToHigh += d1.ShowMessage;
            
            int velocity;
            do
            {
                Console.WriteLine("Please enter the current velocity: ");
                velocity = int.Parse(Console.ReadLine());
                s1.Speed = velocity;

            } while (velocity!=0);

            Console.ReadKey();
        }
    }
}

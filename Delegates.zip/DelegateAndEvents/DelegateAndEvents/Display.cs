﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateAndEvents
{
 public   class Display
    {
        public string Name { get; set; }

        public Display(string name)
        {
            Name = name;
        }

        public void ShowMessage(object o,SpeedEventArgs e)
        {
            Console.WriteLine($"Warning, you are speeding. Current speed is {e.CurrentVelocity}");
        }
    }
}

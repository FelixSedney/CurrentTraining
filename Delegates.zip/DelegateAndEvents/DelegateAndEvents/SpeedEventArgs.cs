﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateAndEvents
{
    public class SpeedEventArgs:EventArgs
    {
        public int CurrentVelocity { get; set; }

        public SpeedEventArgs(int currentVelocity)
        {
            CurrentVelocity = currentVelocity;
        }
    }
}

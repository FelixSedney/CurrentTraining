﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo01
{
    class Program
    {
        //1 delegate definieren
        //2 declareren
        //3 invoke

        delegate void MyDelegate(string s);//1
        static void Main(string[] args)
        {
            MyDelegate md = new MyDelegate(ShowMessage);//2
            md("Hello");

            Console.ReadKey();

        }

        static void ShowMessage(string s)
        {
            Console.WriteLine(s);
        }
    }
}

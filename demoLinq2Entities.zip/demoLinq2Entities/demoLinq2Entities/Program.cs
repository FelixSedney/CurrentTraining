﻿using demoLinq2Entities.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace demoLinq2Entities
{
    class Program
    {
        static void Main(string[] args)
        {
         using ( SchoolContext context = new SchoolContext())
            {
                //var result = context.People.Where(p => p.FirstName.Contains("a"));
                //Console.WriteLine("All students");
                //foreach (var item in result)
                //{
                //    Console.WriteLine($"{item.FirstName} {item.LastName}");
                //}

                var result = context.People.Include(t => t.CourseInstructors).ThenInclude(t => t.Course).Where(p => p.HireDate != null);
                foreach (var person in result)
                {
                    Console.WriteLine($"{person.FirstName}\t{person.LastName}");
                    foreach (var course in person.CourseInstructors)
                    {
                        Console.WriteLine($"\t{course.Course.Title}");
                    }
                }

            }
            
        }
    }
}

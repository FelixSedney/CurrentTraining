﻿using System;
using System.Collections.Generic;

#nullable disable

namespace demoLinq2Entities.Models
{
    public partial class Course
    {
        public Course()
        {
            CourseInstructors = new HashSet<CourseInstructor>();
        }

        public int CourseId { get; set; }
        public string Title { get; set; }
        public int Credits { get; set; }
        public int DepartmentId { get; set; }

        public virtual ICollection<CourseInstructor> CourseInstructors { get; set; }
    }
}

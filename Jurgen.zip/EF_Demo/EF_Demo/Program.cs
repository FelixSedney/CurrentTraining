﻿using System;
using System.Linq;//Language integrated query

namespace EF_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            using (PersonContext context = new PersonContext())
            {
                context.Database.EnsureDeleted();
                context.Database.EnsureCreated();
                Person p1 = new Person("vera", "smid", "kerkstraat 12", 21);
                Person p2 = new Person("gerard", "schilder", "dorpsstraat 34", 34);
                Person p3 = new Person("erma", "timmerman", "langestraat 1234", 45);
                Person p4 = new Person("edward", "metselaar", "schoolstraat 67", 43);

                context.Persons.AddRange(p1, p2, p3, p4);

                context.SaveChanges();
            }


            using (PersonContext context = new PersonContext())
            {
                //foreach (var person in context.Persons)
                //{
                //    Console.WriteLine(person);
                //}

                //var result = from person in context.Persons
                //             where person.Age>40
                //             select person;

                var result = context.Persons.Where(p => p.Age > 40);//Lambda expression
                                                                    //Extension method

                foreach (var person in result)
                {
                    Console.WriteLine(person);
                }

            }

            }
    }
}

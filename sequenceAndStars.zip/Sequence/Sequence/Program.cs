﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sequence
{
    class Program
    {
        static void Main(string[] args)
        {
            int delta = 1;
            int value = 1;
            while (value < 1000)
            {
                Console.Write($"{value}\t");
                value += delta;
                delta++;
                //value += delta++;
            }
            
            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stars1
{
    class Program
    {
        static void Main(string[] args)
        {
            const int  NUMBER_OF_ROWS= 3;
            int numberOfStars = 1;

            for (int i = 0; i < NUMBER_OF_ROWS; i++)
            {
                for (int j = 0 ; j < numberOfStars; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
                numberOfStars += 2;
            }
            Console.ReadKey();
        }
    }
}

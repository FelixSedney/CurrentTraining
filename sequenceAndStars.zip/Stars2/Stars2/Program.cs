﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stars2
{
    class Program
    {
        static void Main(string[] args)
        {
            const int NUMBER_OF_ROWS = 3;
            int numberOfStars = 1;
            int numberOfSpaces = NUMBER_OF_ROWS - 1;

            for (int i = 0; i < NUMBER_OF_ROWS; i++)
            {
                for (int k = 0; k < numberOfSpaces; k++)
                {
                    Console.Write(" ");
                }
                for (int j = 0; j < numberOfStars; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
                numberOfStars += 2;
                numberOfSpaces--;
            }
            Console.ReadKey();
        }
    }

}

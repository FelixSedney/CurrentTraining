﻿using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Timers;
using System.Windows;

namespace AsyncDemo01
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        //program gets all subfolders from a certain folder. Meanwhile the progress bar is updated to show the progress.
        //Run the program and notice the results. Note that it takes some time before the UI responds.
        //Use an asynchronous solution to avoid the problems that you have observed.

        public MainWindow()
        {
            InitializeComponent();
        }
        List<string> _folders = new List<string>();
        System.Timers.Timer _timer;


        private  void ShowButton_Click(object sender, RoutedEventArgs e)
        {
            _timer.Start();
            ProjectsListBox.ItemsSource = _folders;//the ProjectListBox is connected to the collection _folders
            StatusTextBlock.Text = "Searching";
            //because the method runs on the main thread, the progress bar won't be updated.
             GetFolders(@"c:\temp");//adjust the folder to your situation
            ProjectsListBox.ItemsSource = _folders;
            StatusTextBlock.Text = "Ready";
            _timer.Stop();
            Pb1.Value = 0;
        }



        private void GetFolders(string path)
        {
            //recursive method that gets all folders in the folder given by path.
            Thread.Sleep(120);
            foreach (var item in Directory.GetDirectories(path))
            {
                _folders.Add(item);
                foreach (var file in Directory.GetFiles(item))
                {
                    _folders.Add("  " + file);
                }
                foreach (var subFolder in Directory.GetDirectories(item))
                {
                    GetFolders(subFolder);
                }
            }
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //when window is loaded initialize the timer tat is used to control the progressbar
            _timer = new System.Timers.Timer(500);
            _timer.Elapsed += Timer_Elapsed;//callback for timer.
        }


        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            //when timer tick occurs, shift the progress bar. If progressbar has reached the max value return to zero
            Pb1.Dispatcher.Invoke(() => Pb1.Value = Pb1.Value % Pb1.Maximum + 10);
        }
    }
}


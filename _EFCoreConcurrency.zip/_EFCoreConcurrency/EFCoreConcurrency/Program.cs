﻿using DAL;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace EFCoreConcurrency
{
    class Program
    {
        static void Main(string[] args)
        {

            //gebruik Add-Migration Intial en Update-database om de initiele db aan te maken.
            //using (BlogContext context = new BlogContext())
            //{
            //    context.Blogs.Add(new Blog() { Title = "Blog1", Rating = 1, URL = "http://blog1" });
            //    context.Blogs.Add(new Blog() { Title = "Blog2", Rating = 2, URL = "http://blog2" });
            //    context.Blogs.Add(new Blog() { Title = "Blog3", Rating = 3, URL = "http://blog3" });
            //    context.Blogs.Add(new Blog() { Title = "Blog4", Rating = 4, URL = "http://blog4" });
            //    context.SaveChanges();
            //}

            //using (BlogContext ctx = new BlogContext())
            //{
            //    foreach (var item in ctx.Blogs)
            //    {
            //        Console.WriteLine(item.Title);
            //    }
            //}

            BlogContext context = null;
            BlogContext ctx = null;
            try
            {
                context = new BlogContext();
                ctx = new BlogContext();

                Blog b2 = context.Blogs.Find(2);
                Blog b02 = ctx.Blogs.Find(2);
                b2.Rating++;
                b02.Title += "#";
                ShowChangeTracker(context);
                ShowChangeTracker(ctx);
                context.SaveChanges();
                ctx.SaveChanges();
                Console.WriteLine("Done");
            }
            catch (DbUpdateConcurrencyException ex)
            {
                ////database wins (first writer wins)
                //ex.Entries.Single().Reload();
                //Console.WriteLine("After Reload");
                //ShowChangeTracker(context);
                //ShowChangeTracker(ctx);

                //client wins (last writer wins)
                var entry = ex.Entries.Single();
                entry.OriginalValues.SetValues(entry.GetDatabaseValues());
                Console.WriteLine("After Reload");
                ShowChangeTracker(context);
                ShowChangeTracker(ctx);
            }

            Console.WriteLine("DONE");
        }


        static void ShowChangeTracker(BlogContext context)
        {
            Console.WriteLine(nameof(context));
            foreach (var item in context.ChangeTracker.Entries())
            {
                foreach (var propName in item.OriginalValues.Properties)
                {
                    Console.Write($"{item.OriginalValues[propName]}\t");
                }
                Console.WriteLine(item.OriginalValues.GetValue<byte[]>("RowVersion")[7]);
                Console.WriteLine();

                foreach (var propName in item.OriginalValues.Properties)
                {
                    Console.Write($"{item.CurrentValues[propName]}\t");
                }
                Console.WriteLine(item.CurrentValues.GetValue<byte[]>("RowVersion")[7]);
                Console.WriteLine();

                Console.WriteLine(item.State);
            }
        }
    }
    }

